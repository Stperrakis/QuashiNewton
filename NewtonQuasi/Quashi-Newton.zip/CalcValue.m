function [ out ] = CalcValue( f,point )
   for i=1:size(point,2)
    
    
    
end

